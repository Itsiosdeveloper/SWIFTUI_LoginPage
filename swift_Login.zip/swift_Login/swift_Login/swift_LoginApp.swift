//
//  swift_LoginApp.swift
//  swift_Login
//
//  Created by SMH on 20/06/24.
//

import SwiftUI

@main
struct swift_LoginApp: App {
    var body: some Scene {
        WindowGroup {
            ContentView()
        }
    }
}
