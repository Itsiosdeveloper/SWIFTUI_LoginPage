//
//  swift_LoginApp.swift
//  ContentView
//
//  Created by SMH on 20/06/24.
//

import SwiftUI

struct ContentView: View {
    @State private var username: String = "" // State variable to hold the username input
    @State private var password: String = "" // State variable to hold the password input
    @State private var isPasswordVisible: Bool = false // State variable to toggle password visibility
    @State private var isLoggingIn: Bool = false // State variable to indicate if the login process is ongoing
    @State private var loginSuccess: Bool = false // State variable to indicate if login is successful
    @State private var logoRotationAngle: Double = 0.0 // State variable to control the rotation angle of the logo
    
    var body: some View {
        ZStack {
            // Background gradient
            LinearGradient(gradient: Gradient(colors: [Color.blue, Color.purple]), startPoint: .topLeading, endPoint: .bottomTrailing)
                .edgesIgnoringSafeArea(.all)
            
            VStack {
                
                Spacer()
                
                // Logo with rotation animation
                Image(systemName: "lock.shield.fill")
                    .font(.system(size: 100))
                    .foregroundColor(.white)
                    .rotationEffect(.degrees(logoRotationAngle))
                    .onAppear {
                        withAnimation(Animation.easeInOut(duration: 4.0).repeatForever()) {
                            self.logoRotationAngle += 360
                        }
                    }
                    .padding(.bottom, 30)
                
                // Username and Password fields
                VStack(spacing: 20) {
                    TextField("Username", text: $username)
                        .textFieldStyle(RoundedBorderTextFieldStyle())
                        .padding()
                    
                    HStack {
                        if isPasswordVisible {
                            TextField("Password", text: $password)
                                .textFieldStyle(RoundedBorderTextFieldStyle())
                        } else {
                            SecureField("Password", text: $password)
                                .textFieldStyle(RoundedBorderTextFieldStyle())
                        }
                        // Button to toggle password visibility
                        Button(action: {
                            withAnimation {
                                self.isPasswordVisible.toggle()
                            }
                        }) {
                            Image(systemName: isPasswordVisible ? "eye.fill" : "eye.slash.fill")
                                .foregroundColor(.white)
                        }
                    }
                    .padding()
                    
                    // Login button
                    Button(action: {
                        // Simulate logging in
                        withAnimation {
                            self.isLoggingIn = true
                        }
                        DispatchQueue.main.asyncAfter(deadline: .now() + 1.5) {
                            withAnimation {
                                self.loginSuccess = true
                            }
                        }
                    }) {
                        Text("Login")
                            .padding()
                            .frame(maxWidth: .infinity)
                            .background(Color.white)
                            .foregroundColor(.blue)
                            .cornerRadius(10)
                            .font(.headline)
                    }
                    .padding()
                    .disabled(isLoggingIn) // Disable button while logging in
                    
                    // Show progress view when logging in
                    if isLoggingIn {
                        ProgressView()
                            .progressViewStyle(CircularProgressViewStyle(tint: .white))
                            .scaleEffect(2)
                            .padding()
                    }
                    
                    // Forget password and create new account buttons
                    HStack {
                        Button(action: {
                            // Forget password action
                        }) {
                            Text("Forget Password?")
                                .foregroundColor(.white)
                                .lineLimit(1)
                                .minimumScaleFactor(0.8)
                        }
                        
                        Spacer()
                        
                        Button(action: {
                            // Create new account action
                        }) {
                            Text("Create New Account")
                                .foregroundColor(.white)
                                .lineLimit(1)
                                .minimumScaleFactor(0.5)
                        }
                    }
                    .padding()
                }
                .frame(width: 300)
                .background(Color.blue.opacity(0.5))
                .cornerRadius(20)
                .shadow(radius: 10)
                .padding()
                
                // Social login section
                VStack {
                    Text("or Connecting with")
                        .foregroundColor(.white)
                        .font(.headline)
                        .padding(.vertical, 10)
                    
                    HStack(spacing: 20) {
                        Button(action: {
                            // Social login action (e.g., Facebook)
                        }) {
                            Image("fb")
                                .resizable()
                                .renderingMode(.original) // Ensure the original image color is used
                                .aspectRatio(contentMode: .fill)
                                .frame(width: 55, height: 55)
                                .clipShape(Circle())
                                .shadow(radius: 5)
                        }
                        
                        Button(action: {
                            // Social login action (e.g., Google)
                        }) {
                            Image("go")
                                .resizable()
                                .aspectRatio(contentMode: .fill)
                                .frame(width: 35, height: 35)
                                .clipShape(Circle())
                                .shadow(radius: 5)
                        }
                        
                        Button(action: {
                            // Social login action (e.g., Apple)
                        }) {
                            Image("apple")
                                .resizable()
                                .aspectRatio(contentMode: .fill)
                                .frame(width: 55, height: 55)
                                .clipShape(Circle())
                                .shadow(radius: 5)
                        }
                    }
                    .padding(.top, 20) // Top padding for social icons
                }
                
                // App name with shimmering bubbles effect
                ShimmeringBubbles(text: "Your App Name")
                    .foregroundColor(.white)
                    .font(.system(size: 24, weight: .bold))
                    .padding(.bottom, 70) // Bottom padding for the app name
            }
            .padding()
            
        }
        .statusBar(hidden: true)
        .animation(.easeInOut(duration: 0.5), value: loginSuccess)
    }
}

struct ContentView_Previews: PreviewProvider {
    static var previews: some View {
        ContentView()
    }
}

struct ShimmeringBubbles: View {
    let text: String
    @State private var isAnimating: Bool = false
    
    var body: some View {
        HStack(spacing: 5) {
            ForEach(Array(text.enumerated()), id: \.offset) { index, char in
                Text(String(char))
                    .font(.system(size: 24, weight: .bold))
                    .foregroundColor(.white)
                    .opacity(isAnimating ? 1.0 : 0.5)
                    .offset(y: isAnimating ? -5 : 0)
            }
        }
        .onAppear {
            withAnimation(Animation.easeInOut(duration: 1.0).repeatForever(autoreverses: true)) {
                self.isAnimating = true
            }
        }
    }
}

